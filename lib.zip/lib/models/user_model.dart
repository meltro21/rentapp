class UserModel {
  String userId;
  String name;
  String eamil;
  String mobileNumber;
  String password;

  UserModel(
      this.userId, this.name, this.eamil, this.mobileNumber, this.password);
}
